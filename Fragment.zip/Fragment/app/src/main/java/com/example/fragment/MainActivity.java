package com.example.fragment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;
import com.google.android.material.tabs.TabLayout; // Import TabLayout

import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    TabLayout tab; // Use TabLayout instead of View
    ViewPager viewpager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tab = findViewById(R.id.tab);
        viewpager = findViewById(R.id.viewpager);

        ViewPagerMessegerAdapter adapter = new ViewPagerMessegerAdapter(getSupportFragmentManager());
        viewpager.setAdapter(adapter);

        tab.setupWithViewPager(viewpager); // Use setupWithViewPager method instead
    }
}