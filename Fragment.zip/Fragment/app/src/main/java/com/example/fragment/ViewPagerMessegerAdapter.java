package com.example.fragment;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

public class ViewPagerMessegerAdapter extends FragmentPagerAdapter {
    public ViewPagerMessegerAdapter(@NonNull FragmentManager fm) {
        super(fm);
    }


    @Override
    public Fragment getItem(int position) { //AS INDEXING STARTS FROM 0 SP '0' index=1 tab, '1' index= 2 tab, '2' index= 3 tab
        if(position==0){ //1 tab
            return new chatFragment();
        } else if (position==1) { //2 tab
            return new statusFragment();
        }else  { //3 tab
            return new callFragment();
        }

    }


    @Override
    public int getCount() {
        return 3;  //no.of tabs
    }


    @Override
    public CharSequence getPageTitle(int position) {
        if(position==0){ //1 tab
            return "Chats";
        } else if (position==1) { //2 tab
            return "Status";
        }else  { //3 tab
            return "Calls";
        }

    }
}
