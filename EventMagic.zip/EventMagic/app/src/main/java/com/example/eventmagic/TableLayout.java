package com.example.eventmagic;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;

public class TableLayout extends AppCompatActivity {

    TabLayout tab; // Use TabLayout instead of View
    ViewPager viewpager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_table_layout);

        tab = findViewById(R.id.tab);
        viewpager = findViewById(R.id.viewpager);

        ViewPagerMessegerAdapter adapter = new ViewPagerMessegerAdapter(getSupportFragmentManager());
        viewpager.setAdapter(adapter);

        tab.setupWithViewPager(viewpager); // Use setupWithViewPager method instead
    }
}