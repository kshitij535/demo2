package com.example.eventmagic;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class feedbackbtn extends AppCompatActivity {

    EditText feedback_username, feedback_usermsg;
    Button feedback_btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedbackbtn);
        feedback_username = findViewById(R.id.getname);
        feedback_usermsg = findViewById(R.id.description);
        feedback_btn = findViewById(R.id.submitbtn);

        feedback_btn.setOnClickListener(new android.view.View.OnClickListener() {
            @Override
            public void onClick(android.view.View view) {
                feedback_data_submit();
            }
        });
    }
    private void feedback_data_submit() {
        String name = feedback_username.getText().toString();
        String feedback = feedback_usermsg.getText().toString();

        HashMap<String, Object> map = new HashMap<>();
        map.put("Students name:", name);
        map.put("Feedback:", feedback);
        FirebaseDatabase.getInstance().getReference().child("FEEDBACK DATA").push().setValue(map).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    Toast.makeText(feedbackbtn.this, "FEEDBACK SUBMITTED", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "FAILED!!", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}