package com.example.eventmagic;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class Complain extends AppCompatActivity {

    EditText getname, description, rollno;
    Button complain_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complain);

        rollno = findViewById(R.id.getpass);
        getname = findViewById(R.id.getname);
        description = findViewById(R.id.description);
        complain_btn = findViewById(R.id.submitbtn);

        complain_btn.setOnClickListener(new android.view.View.OnClickListener() {
            @Override
            public void onClick(android.view.View view) {
                complain_data_submit();
            }
        });
    }

    private void complain_data_submit() {
        String name = getname.getText().toString();
        String rollNoStr = rollno.getText().toString();

        if (rollNoStr.isEmpty()) {
            // The user has not entered anything for the roll number.
            // You can show an error message or take appropriate action.
            // For example, you can display a toast message to prompt the user to enter a roll number.
            Toast.makeText(this, "Please enter your roll number.", Toast.LENGTH_SHORT).show();
        } else {
            try {
                // Parse the entered value as an integer.
                int rollNo = Integer.parseInt(rollNoStr);

                // At this point, the rollNo variable holds the parsed integer value of the roll number.
                // You can use this rollNo value as needed in your code.
                // For example, you can save the rollNo to a database, use it for processing, etc.
                // ...

                String complain = description.getText().toString();

                HashMap<String, Object> map = new HashMap<>();
                map.put("Students name:", name);
                map.put("Roll Number:", rollNo);
                map.put("Complain:", complain);

                FirebaseDatabase.getInstance().getReference().child("FEEDBACK DATA").push().setValue(map).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(Complain.this, "COMPLAINT REGISTERED!", Toast.LENGTH_SHORT).show();
                            Toast.makeText(Complain.this, "THANK YOU, WE WILL WORK ON IT", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(getApplicationContext(), "FAILED!", Toast.LENGTH_LONG).show();
                        }
                    }
                });
            } catch (NumberFormatException e) {
                // The entered value could not be parsed as a valid integer.
                // Handle this case by showing an error message or taking appropriate action.
                // For example, display a toast message indicating that an invalid roll number was entered.
                Toast.makeText(this, "Invalid roll number. Please enter a valid number.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
