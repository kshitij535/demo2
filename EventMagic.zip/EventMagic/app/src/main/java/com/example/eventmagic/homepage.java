package com.example.eventmagic;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class homepage extends AppCompatActivity {
    Button feedbtn,compl_btn,dev, college_info;
    TextView headerTextView; // Add this line to declare the TextView for the header
    DatabaseReference usersRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);

        // Initialize the TextView for the header
        headerTextView = findViewById(R.id.hd); // Replace with the actual ID of your header TextView

        // Initialize the database reference
        usersRef = FirebaseDatabase.getInstance().getReference().child("users");

        // Retrieve the current user ID
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            final String userId = currentUser.getUid();

            // Fetch the username from the Firebase Realtime Database
            usersRef.child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        String username = dataSnapshot.child("username").getValue(String.class);
                        if (username != null && !username.isEmpty()) {
                            // Store the username in SharedPreferences
                            SharedPreferences sharedPreferences = getSharedPreferences("my_app_prefs", Context.MODE_PRIVATE);
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putString("username_key", username);
                            editor.apply();

                            // Update the header view to display the welcome message
                            headerTextView.setText("Welcome "+username +" !");
                        }
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                    // Handle any error during data fetching
                }
            });
        }

        feedbtn = findViewById(R.id.feed_btn);
        feedbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(homepage.this, feedbackbtn.class);
                startActivity(i);
            }
        });

        compl_btn = findViewById(R.id.comb);
        compl_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(homepage.this, Complain.class);
                startActivity(i);
            }
        });
        college_info = findViewById(R.id.collinfo);
        college_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(homepage.this, TableLayout.class);
                startActivity(i);
            }
        });
       dev = findViewById(R.id.dev);
       dev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(homepage.this, DI.class);
                startActivity(i);
            }
        });
    }
}
