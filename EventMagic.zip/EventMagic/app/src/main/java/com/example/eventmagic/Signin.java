package com.example.eventmagic;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Signin extends AppCompatActivity {

    TextView t1;
    EditText loginemail, loginpassword;
    Button loginbtn;
    FirebaseAuth f1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);

        t1 = findViewById(R.id.newuserpage);
        t1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Signin.this, signup.class);
                startActivity(i);
            }
        });

        f1 = FirebaseAuth.getInstance();
        loginemail = findViewById(R.id.loginemail);
        loginpassword = findViewById(R.id.loginpass);
        loginbtn = findViewById(R.id.loginbtn);
        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user_email = loginemail.getText().toString();
                String user_pass = loginpassword.getText().toString();
                f1.signInWithEmailAndPassword(user_email, user_pass).addOnSuccessListener(Signin.this, new OnSuccessListener<AuthResult>() {
                    @Override
                    public void onSuccess(AuthResult authResult) {
                        FirebaseUser currentUser = f1.getCurrentUser();
                        if (currentUser != null) {
                            String username = currentUser.getDisplayName();
                            if (username != null && !username.isEmpty()) {
                                // Store the username in SharedPreferences
                                SharedPreferences sharedPreferences = getSharedPreferences("my_app_prefs", Context.MODE_PRIVATE);
                                SharedPreferences.Editor editor = sharedPreferences.edit();
                                editor.putString("username_key", username);
                                editor.apply();
                            }
                        }
                        Toast.makeText(Signin.this, "LOGIN SUCCESSFUL!!", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(Signin.this, homepage.class));
                    }
                });
            }
        });
    }
}

